//use at your own risk
//modify according to your own likings
var ff, chrome, safari;
//Check if browser is IE or not
if (navigator.userAgent.search("MSIE") >= 0) {
  //alert("Browser is InternetExplorer");
}
//Check if browser is Chrome or not
else if (navigator.userAgent.search("Chrome") >= 0) {
  //alert("Browser is Chrome");
  chrome = true;
}
//Check if browser is Firefox or not
else if (navigator.userAgent.search("Firefox") >= 0) {
  //alert("Browser is FireFox");
  ff = true;
}
//Check if browser is Safari or not
else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
  //alert("Browser is Safari");
  safari = true;
}
//Check if browser is Opera or not
else if (navigator.userAgent.search("Opera") >= 0) {
  //alert("Browser is Opera");
}

var clicked = false;
//delay appending dom elements and function calls
var timeoutstart = 400;
//fade in dom elements
var fadeInElement = 500;
var fadeOutEnd = 500;
var $window = jQuery(window);
var percent, $winWidth, $winHeight, proportionWin, stageW, stageH, illuW, illuH, textContH, exitBottom;
// Variabels domElements
var overlay = '<div id="overlay"></div>';
var emitter = '<div id="emitter"></div>';
var text = '<div class="textCont"></div>';
var exit = '<div class="exit">X</div>';
var stage = '<div id="stage"></div>';
var image = '<div class="image"></div>';
//variables for clearTimeOut
var clearImgTime, clearTextTime, clearParticleTime;
// Variabels countTextNumber
var timeoutTexts = 4200;
var delayTextAnim = 2900;
var timeoutParticles = 100;
var counterTexts = -1;
var textArray = ['Lorem ipsum dolor', 'sit amet 2016', 'amet, consectetuer&hellip;', ' Aenean commodo<br>Aenean massa', 'nascetur ridiculus<br>Vivamus elementum<br>Donec pede justo', 'Donec quam felis<br>Etiam rhoncus&rsquo;s neque.', 'Phasellus viverra<br>ullamcorper<br>hendrerit id:', '«metus varius laoreet»', ' Nam eget dui,<br>sem neque,<br>Nullam quis ante&hellip;', 'Nullam quis,<br>Maecenas nec&rsquo;s tincidunt.', 'semper libero<br>amet adipiscing&hellip;', 'Nullam quis ante<br>sagittis magna&rsquo;Etiam.', '&', 'Sed consequat<br>fringilla mauris&hellip;', 'bibendum sodales<br>ametNibh.', 'fringilla mauris<br>Aliquam lorem', 'laoreet n&rsquo;Aliquam<br>Tincidunt!', 'adipiscing<br>fringilla!!!', '&', '«Etiam rhoncus»<br>ante tincidunt', 'nec odio et ante<br>odio&rsquo;s Sodales.', 'Maecenas uff<br>magna.com <span class="inline">&#9829;</span>'];

var numbTexts = textArray.length - 1;

//console.log(numbTexts);
// Variabels countImageNumber
var timeoutImages = 1 * timeoutTexts; //6400
var imgDisplayTime = timeoutImages - 1400;
var counterImages = -1;
var imageArray = ['<img src="img/test_waggis4.png" width="340" height="440" alt=""/>', '<img src="img/test_waggis4-flip.png" width="340" height="440" alt=""/>'];


var numbImages = imageArray.length - 1;


function countImageNumber() {
  "use strict";
  if (clicked === false) {
    if (counterImages < numbImages) {
      counterImages++;
      //console.log('Bild'+counterImages+' mal');
      window.setTimeout(countImageNumber, timeoutImages);
    } else if ((counterImages === numbImages)) {
      counterImages = 0;
      window.setTimeout(countImageNumber, timeoutImages);
    }
  }
} // End countImageNumber



function imageAnim() {
  "use strict";
  $winWidth = $window.width();
 
  if (clicked === false) {
    var animelementimage = jQuery(imageArray[counterImages]).appendTo('.image').hide();
    
    if (jQuery('.image img').length > 1) {
      console.log('more than one image');
    } else {
      console.log('one image');
    }

    if ($winWidth < 643) {
      illuW = 270 + 'px';
      illuH = 350 + 'px';
    } else {
      illuW = 340 + 'px';
      illuH = 440 + 'px';
    }
    jQuery('.image').css({
      width: illuW,
      height: illuH,
    });

    if (!jQuery.support.transition) {
      animelementimage.delay(100).fadeIn(fadeInElement).delay(imgDisplayTime).fadeOut(fadeInElement, function() {
        jQuery('.image img').remove();
      });
    } else {
      animelementimage.delay(200).fadeIn(fadeInElement).transition({
        transform: 'rotateY(0deg)',
        width: '100%',
        height: 'auto',
      }, fadeInElement, 'easeOutBack').queue(function() {
        //console.log('step 1');
        animelementimage.dequeue().delay(imgDisplayTime).css({
          transformOrigin: 'right',
        }).queue(function() {
          //jQuery('.image').transition({height:'300px'});
          animelementimage.dequeue().transition({
            transform: 'rotateY(-110deg)',
            width: '100%',
            height: 'auto'
          }, fadeInElement, 'easeInBack', function() {
            //console.log('step 2');
            animelementimage.remove();
          });
        });
      });
    }
    clearImgTime = window.setTimeout(imageAnim, timeoutImages);
  } else {
    jQuery('.image img').fadeOut().remove();

  }
}







// Variabels textAnim
var sizeText, topV;
var startAngleMax = 3;
var startAngleMin = 0;
var startAngle;

function randAngle() {
  "use strict";

  if (clicked === false) {
    startAngle = Math.random() * (startAngleMax - startAngleMin + 0.14) + startAngleMin;
  }
}

//create dom elements
function domElements() {
  "use strict";
  //jQuery('.image, .image img').remove();
  jQuery('body').delay(timeoutstart).append(overlay);
  jQuery('#overlay').delay(timeoutstart).append(emitter, stage);
  jQuery('body').delay(timeoutstart).append(text, image);
  jQuery('#stage').delay(timeoutstart).append(exit);
  jQuery('#stage').delay(timeoutstart).transition({'transform':'scale(1)'});
  jQuery('#overlay').css({'display':'none'}).fadeIn(fadeInElement, function() {
  jQuery('.image').fadeIn(fadeInElement, function() {
  jQuery('.exit').fadeIn(fadeInElement);
    });
  });

  $winWidth = $window.width();
  $winHeight = $window.height();
  proportionWin = ($winWidth / $winHeight);

  //insert different margin percentages for landscape and portrait
  if ($winWidth < $winHeight) {
    percent = 135;
  } else {
    percent = 78; //78
  }
  if ($winWidth < 643) {
    stageW = 470 + 'px';
    stageH = 470 + 'px';
  } else {
    stageW = 604 + 'px';
    stageH = 604 + 'px';
  }
  //apply margins and dimensions to stage
  jQuery('#stage').css({
    top: -percent * proportionWin + '%',
    left: -percent * proportionWin + '%',
    bottom: -percent * proportionWin + '%',
    right: -percent * proportionWin + '%',
    width: stageW,
    height: stageH
  });

}


//Random direction
var minusPlus;

function minusOrPlus() {
  "use strict";
  if (clicked === false) {
    minusPlus = (Math.round(Math.random()) * 2 - 1);
  }
}


function countTextNumber() {
  "use strict";
  if (clicked === false) {
    //timeoutTexts = 4500;
    if (counterTexts < numbTexts) {
      counterTexts++;
      //console.log(counterTexts + ' mal');
      window.setTimeout(countTextNumber, timeoutTexts);
    } else if ((counterTexts === numbTexts)) {
      counterTexts = 0;
      window.setTimeout(countTextNumber, timeoutTexts);
    }
  } //end if clicked
} // end countTextNumber



// Variabels countAllParticles()


// Variabels countParticlesNumber
var counterParticles = 0;
var loopParticles = 0;
var maxParticles = 10;
var clearPartNumberT, countAllPartT;

function countParticlesNumber() {
  "use strict";
  if (clicked === false) {
    if (counterParticles < maxParticles) {
      counterParticles++;
      //console.log(counterParticles+' mal');
      clearPartNumberT = window.setTimeout(countParticlesNumber, timeoutParticles);
    } else if ((counterParticles === maxParticles)) {
      counterParticles = 0;
      //increase the loop number
      loopParticles++;
      //console.log(loopParticles);
      clearPartNumberT = window.setTimeout(countParticlesNumber, timeoutParticles);
    }
  }
}

var neverReachParticlesValue = 11;
var counterAllParticles = 0;

//count bullets forever
function countAllParticles() {
  "use strict";
  if (clicked === false) {
    if (counterParticles < neverReachParticlesValue) {
      counterAllParticles++;
      //console.log(counterAllParticles);
      countAllPartT = window.setTimeout(countAllParticles, timeoutParticles);
    } else if (counterParticles === neverReachParticlesValue) {
      counterAllParticles = 0;
      countAllPartT = window.setTimeout(countAllParticles, timeoutParticles);
    }
  }
}

function particleAnim() {
  "use strict";
  if (clicked === false) {
    var $window = jQuery(window);
    //font size bullets
    //var sizeEntity = 6;
    var sizeEntity = 2 * (Math.floor(Math.random() * 2) + 2);
    //change y offset for hearts and radius for bullets
    var heartsYoffset = 100;
    //values for circular motion
    var radius = 200;
    /*the higher the value the smoother the motion and
    the smaller the distance between bullets*/
    var totalX = 60;
    //the higher the greater the distance between bullets
    var distanceBullets = 5;
    if ($window.width() < 643) {
      heartsYoffset = 78;
      radius = 150;
      totalX = 40;
      distanceBullets = 6;
      sizeEntity = 2 * (Math.floor(Math.random() * 2) + 1);
      sizeEntity = 5;
    }
    //alternate y offset from bottom to top with modulo
    var remainsHearts = loopParticles % 2;
    if (remainsHearts === 0) {
      heartsYoffset = -heartsYoffset;
    } else {
      heartsYoffset = heartsYoffset;
    }

    //offset X for the hearts 
    var heartsXoffset = counterParticles * 40;

    //console.log(fields);//2*3
    //var total = jQuery('.particle').length;
    //alpha results in a fix value
    var alpha = Math.PI * distanceBullets / totalX;
    //console.log(alpha);
    //where starts the animation; value 1 means top, 
    //with random value each bullet has a different angle
    //var startAngleRandom = Math.random() * Math.PI;
    //where starts the animation; value 1 means top,
    var startAngle = 1;
    //var thetaDyn = counterAllParticles % 40;
    //console.log(thetaDyn);
    var theta = Math.PI / 2 * startAngle - alpha * counterAllParticles;
    //console.log(theta);

    var bulletCircleX = Math.floor(Math.cos(theta) * radius);
    var bulletCircleY = Math.floor(Math.sin(theta) * radius);
    //var bulletCircleXB = Math.floor(Math.sin(theta - 1) * radius);
    //var bulletCircleYB = Math.floor(Math.cos(theta - 1) * radius);
    //start from the center
	
    var centerX = $window.width() / 2 - 35;
    var centerY = $window.height() / 2 - 60;
    //console.log(centerX+' x');
    var calcBulletCircleX = bulletCircleX;
    var calcBulletCircleY = bulletCircleY;
    //var calcBulletCircleXB = centerX - bulletCircleXB;
    //var calcBulletCircleYB = centerY - bulletCircleYB;

    var offsets = document.getElementById('emitter').getBoundingClientRect();


    //console.log(remainsHearts);  
    var emitterWidthX = jQuery('#emitter').width() - 50;
    var emitterHeightY = jQuery('#emitter').height() - 50;
    //console.log('width' + emitterWidthX);
    var y = Math.floor(Math.random() * emitterHeightY) + (Math.floor(offsets.top) - 50);
    var x = Math.floor(Math.random() * emitterWidthX) + (Math.floor(offsets.left) - 50);
    var yHearts = Math.floor(heartsYoffset);
	//mit 200 werden die particle besser eingemitten noch nicht perfekt
    var xHearts = Math.floor(heartsXoffset-200);

    //var sizeEntity2 = 3 * (Math.floor(Math.random() * 4) + 1);
    //console.log('sizeEntity' + sizeEntity);
    //var yval = (1 * (Math.floor(Math.random() * 200) - 50));

    //var moveX = x + yval,
    //moveY = y + yval,
    //moveXstart = x,
    //moveYstart = y;
    //var xval = (1 * (Math.floor(Math.random() * 200) - 50));
    var xBulletAway = Math.floor(Math.floor(Math.random() * 2000) - 1000) / 4;
    var yBulletAway = Math.floor(Math.floor(Math.random() * 1700) - 800) / 4;
	console.log('x: '+x+' minus xBulletAway ' + xBulletAway);
    var time1 = 1000;
    var time2 = 1500;
    var opacity = 0.6;
    //rotation hearts first phase A
    var minA_AngleHearts = -20;
    var maxA_AngleHearts = 20;
    var randomA_AngleHearts = Math.floor(Math.random() * (maxA_AngleHearts - minA_AngleHearts + 1)) + minA_AngleHearts;
    //var vWinkelH = randomA_AngleHearts;
    //rotation hearts second phase B
    var minB_AngleHearts = -45;
    var maxB_AngleHearts = 45;
    var randomB_AngleHearts = Math.floor(Math.random() * (maxB_AngleHearts - minB_AngleHearts + 1)) + minB_AngleHearts;
    var varAngle = randomB_AngleHearts;
    var plusOrMinus = (Math.round(Math.random()) * 2 - 1);
    var entity = '&#9679;',
      heart = '&hearts;',
      rotation;
    var colorArray = ['#bf0000', 'black', 'black'];
    var pinkArray = ['#ff69b4', '#ffd700', '#1e90ff', '#ff8c00', '#bf3eff', '#fff68f', '#20b2aa', '#ffaeb9', '#ee3b3b'];
    //var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    //var rotationH=70;
	var hasHearts = false;
    if ((counterTexts > 2 && counterTexts < 5) || (counterTexts > 18 && counterTexts <= 21)) { //&& isAndroid < 1) {
      colorArray = pinkArray;
      opacity = 0.85;
      entity = heart;
      rotation = varAngle;
	  hasHearts = true;
    }
	
	var heartEnd;
	var heartStart;
    if ((counterTexts > 2 && counterTexts < 5) || (counterTexts > 18 && counterTexts <= 21)) {
      calcBulletCircleX = xHearts;
      calcBulletCircleY = yHearts;
      sizeEntity = 2 * (Math.floor(Math.random() * 2) + 2);
      //moveXstart = xS;
      //moveYstart = yS;
	  hasHearts = true;
    }
	if (hasHearts){
		heartStart = 'rotate('+randomA_AngleHearts * plusOrMinus + 'deg) translateX('+calcBulletCircleX+'px) translateY('+calcBulletCircleY+'px)';
		heartEnd = 'rotate('+rotation * plusOrMinus + 'deg) translateY('+ yBulletAway+'px) translateX('+ xBulletAway+'px)';
		}
		else{
			heartStart = 'translateX('+calcBulletCircleX+'px) translateY('+calcBulletCircleY+'px)';
			heartEnd = 'translateY('+ yBulletAway+'px) translateX('+ xBulletAway+'px)';
			}
    var animelement = jQuery('<div class="particle">' + entity + '</div>').appendTo('body').hide();

    var colorEntity = colorArray[Math.floor(Math.random() * colorArray.length)];

    if (!jQuery.support.transition) {
      animelement.css({
        'color': colorEntity,
        'font-size': sizeEntity + 'em',
        'top': centerY + 'px', //offsets
        'left': centerX + 'px',
        'opacity': 0 //offsets

      }).fadeIn(400).animate({
        'top': calcBulletCircleY + 'px', //moveYstart
        'left': calcBulletCircleX + 'px', //moveXstart
        'opacity': opacity
      }, time1).animate({

        'top': y - yBulletAway + 'px', //offsets
        'left': x - xBulletAway + 'px',
        'opacity': 0
      }, time2).fadeOut(170, function() {
        jQuery(this).remove();
      });
      clearParticleTime = window.setTimeout(particleAnim, timeoutParticles);
    } //ende if
    else {
      animelement.css({
        'color': colorEntity,
        'font-size': sizeEntity + 'em',
        'top': centerY + 'px', //moveYstart
        'left': centerX + 'px', //moveXstart
        'opacity': 0 //offsets
      }).fadeIn(400).transition({
        //'font-size': sizeEntity2+'em',
        //'rotate': randomA_AngleHearts * plusOrMinus + 'deg',
        //'top': calcBulletCircleY + 'px', //moveYstart
        //'left': calcBulletCircleX + 'px', //moveXstart
		'transform': heartStart,
        //'top': moveY  + 'px', //offsets
        //'left': moveX  + 'px',
        'opacity': opacity

      }, time1).transition({
        //'font-size': sizeEntity2+2+'em',
		'transform': heartEnd,
		
		//'transform': 'rotate('+rotation * plusOrMinus + 'deg)',
        //'rotate': rotation * plusOrMinus + 'deg',
        //'top': y - yBulletAway + 'px', //offsets y - yBulletAway
        //'left': x - xBulletAway + 'px', //x - xBulletAway
        'opacity': 0
      }, time2).fadeOut(170, function() {
        jQuery(this).remove();
      });
      clearParticleTime = window.setTimeout(particleAnim, timeoutParticles);
    } //ende else
  } //ende funtion// JavaScript Document
}


function textAnim() {
  "use strict";
  if (clicked === false) {
    var sizeText;
    /*variablen für Drehung*/
    var minRotation = 120;
    var maxRotation = 240;
    var randomRotation = Math.floor(Math.random() * (maxRotation - minRotation + 1)) + minRotation;
    //change sizeText according to viewport size
    if ($window.width() > 600) {
      sizeText = 2.75;
    } else {
      sizeText = 2.2;
    }
    var plusOrMinus = (Math.round(Math.random()) * 2 - 1);
    //var sizeText = 1.25* (Math.floor(Math.random()*breiteFont) + 1);
    var xTextAway = (Math.floor(Math.random() * 100)) * plusOrMinus;
    var yTextAway = (Math.floor(Math.random() * 100)) * plusOrMinus;
    var time1 = 500;
    var time2 = 1000;

    //change text position according to counterTexts
    var topV = -10;
    var textPos = [3, 4, 5, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 21];
    var i;
    for (i = 0; i < textPos.length; ++i) {
      //console.log(textPos[i]);
      if (counterTexts === textPos[i]) {
        topV = -25;
      }
    }
    if (counterTexts === 4 || counterTexts === 6 || counterTexts === 8) {
      topV = -45;
    }
    if (counterTexts === 12 || counterTexts === 18) {
      sizeText = sizeText + 3;
      topV = -33;
    }


     var animelementtext = jQuery('<div class="animelementtext">' + textArray[counterTexts] + '</div>').delay(700).appendTo('.textCont');

    if (!jQuery.support.transition) {
      //console.log('nein');
      //alert('ney')	;		
      animelementtext.css({
        'color': 'white',
        'font-size': 0 + 'em',
        'top': 0,
		'opacity': 0

      }).show().animate({
        'opacity': 1,
        'filter': 'alpha(opacity=100)',
        'top': topV,
        'font-size': sizeText + 'em'

      }, time1).delay(delayTextAnim).animate({
        'opacity': 0,
        'filter': 'alpha(opacity=00)',
        'font-size': 0.5 + 'em',
        'top': yTextAway, //offsets
        'left': xTextAway,
        'WebkitTransform': 'rotate(' + 360 + 'deg)',
        '-moz-transform': 'rotate(' + 360 + 'deg)',
        'transform': 'rotate(' + 360 + 'deg)'
      }, time2, function() {
        jQuery(this).remove();
      });
      clearTextTime = window.setTimeout(textAnim, timeoutTexts);
    } //ende if
    else {
      animelementtext.css({
        'color': 'white',
        'font-size': 0 + 'em',
        'top': 0,
		'opacity': 1,
		'transform': 'rotateY( 0deg ) rotateX(120deg)'
      }).transition({
        'opacity': 1,
        'filter': 'alpha(opacity=100)',
        //'top': topV,
        'font-size': sizeText + 'em',
		'transform': 'rotateX(0deg) rotateY(0deg) translateX(0px) translateY('+topV+'px)'
      }, time1, 'easeOutBack').delay(delayTextAnim).transition({
        'font-size': 1.5 + 'em',
		'transform': 'rotateX('+randomRotation * plusOrMinus + 'deg) rotateY('+randomRotation * plusOrMinus + 'deg) translateX('+xTextAway + 'px) translateY('+yTextAway + 'px)',
        //x: xTextAway + 'px', //offsets
        //y: yTextAway + 'px',
        opacity: 0,
        //rotate: randomRotation * plusOrMinus + 'deg'
      }, time2, function() {
        jQuery(this).remove();
      });
      clearTextTime = window.setTimeout(textAnim, timeoutTexts);
    } //ende else
  }
} //ende funtion// JavaScript Document
var turn;
/*calls*/
(function($) {
  "use strict";
  $(function() {
    var trigger = $('#trigger');
    var angleStar = 0;
    var angleMax = 60;
    var angleChange = 1;
    var angleIntervall = 50;
    trigger.delay(fadeInElement).fadeIn(fadeInElement, function() {
      turn = setInterval(function() {
        if (angleStar === angleMax) {
          angleChange = -1;
        }
        if (angleStar === -angleMax) {
          angleChange = 1;
        }
        angleStar += 1 * angleChange;
        trigger.stop().animate({
          "rotate": angleStar + 'deg'
        }, 50);
      }, angleIntervall);
    });

    trigger.on('click', function() {
      if ($('.particle').length === 0 && $('.image img').length === 0 && $('.textCont').length === 0) {
        clicked = false;
        domElements();
        countTextNumber();
        randAngle();
        minusOrPlus();
        countParticlesNumber();
        countAllParticles();
        countImageNumber();
        setTimeout(imageAnim, timeoutstart);
        setTimeout(particleAnim, timeoutstart);
        setTimeout(textAnim, timeoutstart);
        $('#trigger').fadeOut();
        clearInterval(turn);
      }
    });

    //function to alter margin and dimensions on load and on resize
    function stageVar() {
      var $window = $(window);
      $winWidth = $window.width();
      $winHeight = $window.height();
      proportionWin = ($winWidth / $winHeight);

      /*if ($('.image img').length > 1) {
        console.log('yes, there were two and one has been deleted!');
        $('.image img:last-child').remove();
      }*/


      //insert different margin percentages for landscape and portrait
      if ($winWidth < $winHeight) {
        percent = 135;
      } else {
        percent = 78; //78
      }


      //change dimensions of stage and image
      if ($winWidth < 643) {
        stageW = 470 + 'px'; //470
        stageH = 470 + 'px';
        illuW = 270 + 'px';
        illuH = 350 + 'px';
        textContH = 10 + 'px';
        exitBottom = 15 + 'px';
        topV = 130 + 'px';
        sizeText = 1.6;
        if (counterTexts === 3 || counterTexts === 4 || counterTexts === 5) {
          sizeText = sizeText - 0.3;
        }

      } else {
        stageW = 604 + 'px';
        stageH = 604 + 'px';
        illuW = 340 + 'px';
        illuH = 440 + 'px';
        textContH = 50 + 'px';
        exitBottom = 20 + 'px';
        topV = 100 + 'px';
        sizeText = 2.2;
        if (counterTexts === 3 || counterTexts === 4 || counterTexts === 5) {
          sizeText = sizeText - 0.5;
          //topV = 170;
        }
      }

      //apply margins and dimensions to stage
      $('#stage').css({
        top: -percent * proportionWin + '%',
        left: -percent * proportionWin + '%',
        bottom: -percent * proportionWin + '%',
        right: -percent * proportionWin + '%',
        width: stageW,
        height: stageH,
        WebkitTransition: 'all 0.3s ease-in-out',
        MozTransition: 'all 0.3s ease-in-out',
        MsTransition: 'all 0.3s ease-in-out',
        OTransition: 'all 0.3s ease-in-out',
        transition: 'all 0.3s ease-in-out'
      });

      //apply dimensions to image
      $('.image').css({
        width: illuW,
        height: illuH,
        WebkitTransition: 'all 0.3s ease-in-out',
        MozTransition: 'all 0.3s ease-in-out',
        MsTransition: 'all 0.3s ease-in-out',
        OTransition: 'all 0.3s ease-in-out',
        transition: 'all 0.3s ease-in-out'
      });

      //apply new height to text container
      $('.textCont').css({
        height: textContH
      });

      //change bottom of exit button
      $('.exit').css({
        bottom: exitBottom
      });

      //new values for .animelementtext
      $('.animelementtext').css({
        'top': topV,
        'font-size': sizeText,
        WebkitTransition: 'all 0.3s ease-in-out',
        MozTransition: 'all 0.3s ease-in-out',
        MsTransition: 'all 0.3s ease-in-out',
        OTransition: 'all 0.3s ease-in-out',
        transition: 'all 0.3s ease-in-out'
      });
    }

    $window.resize(function() {
      stageVar();
      //clearTimeout(clearImgTime, clearTextTime, clearParticleTime);
    });

    $window.load(function() {
      //stageVar();
    });

    function deleteEmitter2() {
      clicked = true;
      counterTexts = -1;
      counterImages = -1;
      counterParticles = 0;
      counterAllParticles = 0;
      loopParticles = 0;
      clearTimeout(clearImgTime, clearTextTime, clearParticleTime, clearPartNumberT, countAllPartT);
      trigger.delay(2500).fadeIn(fadeInElement, function() {
        clearInterval(turn);
        turn = setInterval(function() {
          if (angleStar === angleMax) {
            angleChange = -1;
          }
          if (angleStar === -angleMax) {
            angleChange = 1;
          }
          angleStar += 1 * angleChange;

          trigger.stop().animate({
            "rotate": angleStar + 'deg'
          }, 100);
        }, angleIntervall);
      });

      $('#stage, .image img, .exit').transition({
        width: '0px',
        height: '0px',
        opacity: 0
      }, fadeOutEnd);

      $('.image, .image img, .textCont, .particle').fadeOut(300, function() {
        $(this).remove();
        $('.exit, #overlay').fadeOut(300, function() {
          //$(".animelementtext").stop();
          $(this).remove();
          //clicked=true;
          //console.log(clicked);
        });
      });
    }

    function deleteEmitter() {
      clicked = true;
      counterTexts = -1;
      counterImages = -1;
      counterParticles = 0;
      counterAllParticles = 0;
      loopParticles = 0;
      clearTimeout(clearImgTime, clearTextTime, clearParticleTime, clearPartNumberT, countAllPartT);
      //clearTimeout(clearTextTime);
      var $window = $(window);
      var centerX = $window.width() / 2;
      var centerY = $window.height() / 2;
      var partikelEnde = $('.particle');
      var partikelPos = $('.particle-pos');


      trigger.delay(2500).fadeIn(fadeInElement, function() {
        clearInterval(turn);
        turn = setInterval(function() {
          if (angleStar === angleMax) {
            angleChange = -1;
          }
          if (angleStar === -angleMax) {
            angleChange = 1;
          }
          angleStar += 1 * angleChange;

          trigger.stop().animate({
            "rotate": angleStar + 'deg'
          }, 100);
        }, angleIntervall);
      });

      $('#stage, .image img, .exit').transition({
        width: '0px',
        height: '0px',
        opacity: 0
      }, fadeOutEnd);

      partikelEnde.each(function() {
        partikelEnde.clearQueue().stop().transition({ //.clearQueue().stop()
          top: centerY + 'px', //'+='+
          left: centerX + 'px',
          rotate: '360deg'
        }, fadeOutEnd);
      });
      partikelPos.transition({ //.clearQueue().stop()
        rotate: '360deg'
      }, fadeOutEnd);
      $('.animelementtext').clearQueue().stop().transition({
        top: '0px',
        left: '0px',
        fontSize: 0,
        opacity: 0,
        rotate: '480deg'
      }, fadeOutEnd, function() {

        $('.image, .image img, .textCont, .animelementtext, .particle, .exit').fadeOut(fadeOutEnd, function() {
          $('#stage, .exit, #overlay, .image, .imagex img, .textCont, .animelementtext, .particle, .exit').remove();
        });
        //});
      });
    } //end deleteEmitter function


    $(window).blur(function() {
      deleteEmitter2();
      console.log('remove Emitter when tab or window are not in fucus');
    });
    $(document).on('touchstart click', function(e) {
      var container = $("#overlay");
      var hide = $(".exit");
      if (container.is(e.target) || hide.is(e.target)) {
        deleteEmitter2();
      } //ende if target
    });
  });
})(jQuery); // JavaScript Document
