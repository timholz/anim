jQuery.extend( jQuery.easing,
{
  easeOutSine: function (x, t, b, c, d) {
    return c * Math.sin(t/d * (Math.PI/2)) + b;
  }
});

var waitForFinalEvent = (function () {
  var timers = {};
  return function (callback, ms, uniqueId) {
    if (!uniqueId) {
      uniqueId = "Don't call this twice without a uniqueId";
    }
    if (timers[uniqueId]) {
      clearTimeout (timers[uniqueId]);
    }
    timers[uniqueId] = setTimeout(callback, ms);
  };
})();



var hasAnim = true, Tvar, safari;
var fCounter = 0, loop;

//Check if browser is IE or not
/*if (navigator.userAgent.search("MSIE") >= 0) {
  //alert("Browser is InternetExplorer");
}
//Check if browser is Chrome or not
else if (navigator.userAgent.search("Chrome") >= 0) {
  //alert("Browser is Chrome");
  chrome = true;
}
//Check if browser is Firefox or not
else if (navigator.userAgent.search("Firefox") >= 0) {
  //alert("Browser is FireFox");
  ff = true;
}*/
//Check if browser is Safari or not
if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
  //console.log("Browser is Safari");
  safari = true;
}
//Check if browser is Opera or not
/*else if (navigator.userAgent.search("Opera") >= 0) {
  //alert("Browser is Opera");
}*/

function hintergrundAnim() {
  if (hasAnim === true){
  fCounter++;
  //console.log('anzahl: '+fCounter);
  //console.log(fCounter);
  /*if (fCounter %10 < 5){
    console.log('stop: '+fCounter);
    return;
  } */
  //fCounter++;
  if (Tvar){
      clearTimeout(Tvar);
      //console.log('cleared');
    }
  var min = 400, max = 1000;
  var random = Math.floor(Math.random() * (max - min + 1)) + min;

  var minH = 190, maxH = 230;
  var randomH = Math.floor(Math.random() * (maxH - minH + 1)) + minH;
  var hue = 'rgb(' + randomH + ',' + randomH + ',' + randomH + ')';
  //console.log(hue);


  var y = -25;
  //console.log(y);
  var min2 = jQuery(window).width();
  var max2 = jQuery(window).width() - jQuery(window).width();
  var random2 = Math.floor(Math.random() * (max2 - min2 + 1)) + min2;
  //var logx = (Math.log(random2));
  //console.log(logx+ ' für: '+random2);
  var x = random2;

  //var percentX = x/min2*100;
  //console.log(percentX+' % von '+x);

  var yval = (Math.floor(Math.random() * jQuery(window).height()));
  if (yval < 200){
    yval = yval +100;
  } else {
    yval = yval;
  }
  //console.log(yval);
  var div, amplX;

  if (yval < 400){
    div = 20;
    amplX = 200;
    //hue = 'blue';
  } else if (yval >=400 && yval < 1000 ) {
    div = 30;
    amplX = 300;
    //hue = 'red';
  } else if (yval >=1000 && yval < 1400 ) {
    div = 35;
    amplX = 400;
    //hue = 'green';
  } else {
    div = 40;
    amplX = 400
  }
  //var yLog = Math.log(yval);
  //je kleiner divLog desto langsamer läuft die anim
  //var divLog = Math.floor(yLog*4.5);
  //je grösser amplX desto weiter ist die X-amplitude
  //var amplX = Math.floor(yLog*35);
  //je kleiner der divisor desto langsamer
  var timeX = Math.floor((yval/div))*1000;
  var ease = 'linear';
  /*if (timeX < 10000){
    console.log(timeX);
    ease = 'easeOutSine';
  } else {
    ease = ease;
  }*/

  //console.log('div: '+div +' divLog: '+ divLog+' amplX2: '+amplX2+' amplX: '+amplX);

  //console.log('zeit: '+time1);
  var time2 = 2000;
  var timeout = 500;
    if (safari){
    timeout = 800;
    //console.log('timeout: '+timeout);
  } else {
    timeout = timeout;
    //console.log('timeout: '+timeout);
  }
  //'&#10052;','&#10052;','&#10052;','&#x2745;',
  //var textArray = ['&#8902;','&#9734;', '&#9733;', '&#9733;', '&#9733;', '&#9734', '&#9733;', '&#9733;', '&#9733;','&#8902;','&#8902;','&#9734','&#8902;'];
  var textArray = ['&#x2736;','&#x2736;','&#x2735;','&#x2735;','&#9734;', '&#9733;', '&#9734;', '&#9733;', '&#9734', '&#9733;', '&#9733;'];
  var randomNumber = Math.floor(Math.random() * textArray.length);

 //var minFS = 28, maxFS = 32;
 //var randomFS = Math.random() * (maxFS - minFS) + minFS;
  var fsize = '1.8em';
 
  if (textArray[randomNumber] === '&#x2735;' || textArray[randomNumber] === '&#x2736;'){
    fsize = '2.2em';
  } else {
    fsize = fsize;
  }
  //var fsize = '30px';
  var animelement = jQuery('<div class="animelement">' + textArray[randomNumber] + '</div>').appendTo('body').hide();

  var plusOrMinus = Math.round(Math.random()) * 2 - 1;
  var plusOrMinus2 = Math.round(Math.random()) * 2 - 1;
  var xval = (Math.floor(Math.random() * amplX))*plusOrMinus2;
  //console.log(xval+' für yval: '+yval);
  //var xval = amplX*plusOrMinus2;
  var endX = Math.floor(xval/45 * plusOrMinus)+(10*plusOrMinus2);
  var yweg = (Math.floor(Math.random() * 25))*plusOrMinus;
  var rotateA = (Math.floor(yval)+random)*plusOrMinus;
  //console.log(rotateA);


  
    //console.log('xval: '+xval);
    //console.log(xval);
    //console.log('endX: '+endX+' yweg: '+yweg);
    if (!jQuery.support.transition) {
      //variablen nur für diesen modus
      timeX = timeX*2;
      var opaQ = 0,
      angle = 0,
      leftX = 0,
      topY=0,
      trueR = true,
      //addRotation2 = Math.floor(rotateA/200),
      addRotation = Math.floor(rotateA/300);
      //console.log(addRotation);
      if (fCounter %2 === 0){
          trueR = true;
        }else {
          trueR = false;
        }
      //console.log('no support');      
      animelement.show().css({
        'font-weight': '900',
        'font-size': fsize,
        'color': hue,
        'z-index': 10000,
        'top': y, //offsets
        'left': x, //offsets
        'position': 'absolute',
        'opacity': 0.7,
        'filter': 'alpha(opacity=80)',
        /*'transform': 'rotate(' + rotateA + 'deg)',*/
        'user-select': 'none'

      }).show().animate({
        opacity: 0.2,
        transform: 'translateX(' + leftX + 'px) translateY(' + yval + 'px) rotateZ(' + angle + 'deg)',
        top: yval + 'px'
      }, {
        step: function(now, fx) {
          topY = now;

          if (plusOrMinus === 1) {
            //schwanken
            //angle = (Math.sin(now / 10) * 30) * plusOrMinus;
            angle = now * plusOrMinus;
          } else {
            //ganze Drehung
            if (trueR){
            angle = now * addRotation;
          } else {
            angle = now * -addRotation;
          }
          }

          if (fx.prop === 'opacity') {
            //console.log(now);
            opaQ = now;
            //console.log(opaQ);
          }
          //randomH/5 amplitude je kleiner der divisor desto grösser die amplitude
          //leftX = ((Math.sin(now / 20) + 2 * Math.sin(now / 40)) * Math.floor(randomH/7)) * plusOrMinus; //randomH/5 amplitude
          leftX = now * plusOrMinus; //randomH/5 amplitude
          //console.log(leftX);
          jQuery(this).css({
            opacity: opaQ,
            transform: 'translateX(' + leftX + x + 'px) translateY(' + topY + 'px) rotateZ(' + angle + 'deg)',
          });
        }, // ende step 
        duration: timeX,
        easing: ease,
        //complete: function(){
          //console.log('getCurrentRotation(jQuery(this))');
          //angleX = getRotationDegrees(jQuery(this));
          //angleX = angleX*plusOrMinus;
        //}
      })/*.animate({
        opacity: 0,
        //rotation: -360,
        //left: leftX + x + endX+100,
        //top: yval + yweg,
      }, {
        step: function(now,fx) {
      
        //angle -= gurk;
        //leftX +=Math.cos(now*5)*1;

        if (trueR){
          angle += addRotation2;
          leftX +=Math.cos(now*10)*plusOrMinus;
          topY -= Math.sin(now*10)*plusOrMinus2;

        } else {
          angle -= addRotation2;
          leftX -=Math.cos(now*10)*plusOrMinus;
          topY += Math.sin(now*10)*plusOrMinus2;
        }
           

            if (fx.prop === 'opacity') {
            //console.log(now);
            opaQ = now;
            //console.log(opaQ);
          }

          
          jQuery(this).css({'transform':'translateX(' + leftX + 'px) translateY(' + topY + 'px) rotate('+angle+'deg)','opacity':opaQ});  
        },
        duration:time2,
        easing: "linear",
    })*/.fadeOut(700, function() {
        jQuery(this).remove();
      });
      Tvar = window.setTimeout(hintergrundAnim, timeout);
    } //ende if
      else {

        /*if (plusOrMinus < 0){
          xval = (xval)*-1;
          //console.log('neg: '+xval);
          //hue = 'rgb(188, 72, 37,0.5)';
        }else {
          xval = xval;
          //console.log('pos: '+xval);
        }*/

      animelement.css({
        'font-weight': '900',
        'font-size': fsize,
        'color': hue,
        'z-index': 10000,
        'top': y, //offsets
        'left': x, //offsets
        'position': 'absolute',
        'opacity': 0.8,
        /*'-webkit-transform': 'rotateZ(45deg)',
        'transform': 'rotateZ(45deg)',*/
        'user-select': 'none'

      }).show().transition({
        'opacity': 0.4,
        'filter': 'alpha(opacity=40)',
        //'top': yval, //offsets
        //'left': x + (xval * plusOrMinus),
        //drehung funktioniert nicht
        'transform': 'translateX('+xval+'px) translateY('+yval+'px) rotateZ('+rotateA+'deg)',
        //x: yval+xval,//yval für x und y ergibt senkrechte animation
        //y: yval,
        //rotate: rotateA


      }, timeX, ease).transition({
        'opacity': 0,
        x: '+='+endX,
        y: '+='+yweg,
        rotate: '+=' + random * plusOrMinus + 'deg'
        //'top': yval + yweg, //offsets
        //'left': endX,
        //'transform': 'rotate(' + random * plusOrMinus + 'deg)'
      }, time2, 'easeOutSine').fadeOut(700, function() {
          jQuery(this).remove();
      });
      Tvar = window.setTimeout(hintergrundAnim, timeout);
    } //ende else
  }//ende if hasAnim
  //console.log(fCounter);
} //ende funtion// JavaScript Document

/*call hintergrundAnim*/
(function($) {
  $(function() {
    var $window = $(window), TvarX, ftimeout = 500, TvarTest;
    hasAnim = true;

    

    /*$("#set").click(function(e) {
      e.preventDefault();
      setResetInterval(true);
    });

    $("#stop").click(function(e) {
      e.preventDefault();
      setResetInterval(false);
    });*/
    

    

    

    function bganim() {
      if ($window.width() > 320) { //anfang if
        if (hasAnim === false) {
          return;
        }

        hasAnim = true;
        hintergrundAnim();
      } //ende if 
      else {
        hasAnim = false;
        $('.animelement').stop().remove();
        clearTimeout(Tvar);
        clearTimeout(TvarX);
      }
    } //ende funktion
    //setInterval(bganim, 5000);
    //bganim();


    /*var timer = 0;

    function setResetInterval(bool) {
      if (bool) {
        timer = setInterval(function() {
          console.log('laufzeit: 5 Sek');
          hasAnim = true;
          hintergrundAnim();
          setTimeout(function() {
            hasAnim = false;
            //hintergrundAnim();
            console.log('pause 7 Sek.');
            //$('.animelement').stop().remove();
          }, 2000);
        }, 5000);
      } else {
        clearInterval(timer);
      }
    }
    setResetInterval(true);*/

    TvarX = window.setTimeout(bganim, ftimeout);
   

    /*var cycleTimer;

    function startCycle() {
       cycleTimer = setInterval(bganim, 500);
    }

    // start to automatically cycle slides
    startCycle();


    // function to stop auto-cycle
    function stopCycle() {
       clearInterval(cycleTimer);
       setTimeout(startCycle, 6000); // restart after 5 seconds
    }
    stopCycle();*/

    $window.blur(function() {

      $('.animelement').stop().remove();
      hasAnim = false;
      clearTimeout(Tvar);
      clearTimeout(TvarX);
      fCounter = 0;
      //test ob animelent ist vorhanden oder nicht
      /*if ($('.animelement').length){
      console.log('vorhanden');
    } else {
      console.log('nicht vorhanden');
    }*/
      //setResetInterval(false);
    });

    $window.on('focus', function() {
      hasAnim = true;
      //bganim();
      TvarX = window.setTimeout(bganim, ftimeout);
      //setResetInterval(true);
    });

    $window.resize(function() {
      $('.animelement').stop().remove();
      hasAnim = false;
      clearTimeout(Tvar);
      clearTimeout(TvarX);
      fCounter = 0;
      //setResetInterval(false);
      //test ob animelent ist vorhanden oder nicht
      /*if ($('.animelement').length){
      console.log('vorhanden');
    } else {
      console.log('nicht vorhanden');
    }*/

      waitForFinalEvent(function(){
      hasAnim = true;
      //console.log('Resize...');
      //bganim();
      TvarX = window.setTimeout(bganim, ftimeout);
      //setResetInterval(true);
      //console.log('restart anim');
    }, 500, "restartX amim");
      //return false;
    });




  });
})(jQuery);
