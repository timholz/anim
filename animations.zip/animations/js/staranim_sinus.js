jQuery.extend( jQuery.easing,
{
  easeOutSine: function (x, t, b, c, d) {
    return c * Math.sin(t/d * (Math.PI/2)) + b;
  }
});

var waitForFinalEvent = (function () {
  var timers = {};
  return function (callback, ms, uniqueId) {
    if (!uniqueId) {
      uniqueId = "Don't call this twice without a uniqueId";
    }
    if (timers[uniqueId]) {
      clearTimeout (timers[uniqueId]);
    }
    timers[uniqueId] = setTimeout(callback, ms);
  };
})();

var hasAnim = true, Tvar;
var fCounter = 0;

function hintergrundAnim() {
  if (hasAnim === true){
  fCounter++;
  //console.log(countEl);
  var min = 400, max = 1000;
  var random = Math.floor(Math.random() * (max - min + 1)) + min;

  //var minR = 360, maxR = 1000;
  //var randomR = Math.floor(Math.random() * (maxR - minR + 1)) + minR;

  var minH = 180, maxH = 240;
  var randomH = Math.floor(Math.random() * (maxH - minH + 1)) + minH;
  var hue = 'rgb(' + randomH + ',' + randomH + ',' + randomH + ')';
  //console.log(hue);


  var y = -25;
  //console.log(y);
  var min2 = parseInt(jQuery(window).width());
  var max2 = jQuery(window).width() - parseInt(jQuery(window).width());
  var random2 = Math.floor(Math.random() * (max2 - min2 + 1)) + min2;

  var x = random2;
  //console.log(x);

  var yval = (Math.floor(Math.random() * jQuery(window).height()))+200;
  var div;

  if (yval < 400){
    div = 10;
  } else if (yval >=400 && yval < 1000 ) {
    div = 15;
  } else if (yval >=1000 && yval < 1400 ) {
    div = 20;
  } else {
    div = 25
  }
  var amplitude = Math.random(Math.log(yval))*350;
  console.log('amplitude: '+amplitude);
  //je kleiner der divisor desto langsamer
  var timeX = Math.floor((yval/div))*1000;
  //console.log('zeit: '+timeX);

  //console.log('zeit: '+time1);
  var time2 = 2000;
  var timeout = 700;
  //'&#10052;','&#10052;','&#10052;','&#x2745;',
  //var textArray = ['&#8902;','&#9734;', '&#9733;', '&#9733;', '&#9733;', '&#9734', '&#9733;', '&#9733;', '&#9733;','&#8902;','&#8902;','&#9734','&#8902;'];
  var textArray = ['&#9734;', '&#9733;', '&#9733;', '&#9733;', '&#9734', '&#9733;', '&#9733;', '&#9733;'];
  var randomNumber = Math.floor(Math.random() * textArray.length);

 //var minFS = 28, maxFS = 32;
 //var randomFS = Math.random() * (maxFS - minFS) + minFS;
  var fsize = '1.8em';;
 
  /*if (textArray[randomNumber] === '&#8902;'){
    fsize = '2.4em';
  } else {
    fsize = '1.6em';
  }*/
  //var fsize = '30px';
  var animelement = jQuery('<div class="animelement">' + textArray[randomNumber] + '</div>').appendTo('body').hide();

  var plusOrMinus = Math.round(Math.random()) * 2 - 1;
  var plusOrMinus2 = Math.round(Math.random()) * 2 - 1;
  var xval = (Math.floor(Math.random() * amplitude))*plusOrMinus2;
  var endX = Math.floor(xval/45 * plusOrMinus)+(10*plusOrMinus2);
  var yweg = (Math.floor(Math.random() * 25))*plusOrMinus;
  var rotateA = (Math.floor(yval)+random)*plusOrMinus;
  
    //console.log(xval);
    //console.log(xval);
    //console.log('endX: '+endX+' yweg: '+yweg);
      //variablen nur für diesen modus
      var opaQ = 0,
      angle = 0,
      leftX = 0,
      topY=0,
      trueR = true,
      addRotation = rotateA/200,
      addRotation2 = rotateA/100;

      if (fCounter %2 === 0){
          trueR = true;
        }else {
          trueR = false;
        }
      //console.log('no support');      
      animelement.show().css({
        'font-weight': '900',
        'font-size': fsize,
        'color': hue,
        'z-index': 10000,
        'top': y, //offsets
        'left': x, //offsets
        'position': 'absolute',
        'opacity': 0.7,
        'filter': 'alpha(opacity=80)',
        'transform': 'rotate(' + rotateA + 'deg)',
        'user-select': 'none'

      }).show().animate({
        opacity: 0.4,
        transform: 'translateX(' + leftX + 'px) translateY(' + yval + 'px) rotateZ(' + angle + 'deg)',
        top: yval + 'px'
      }, {
        step: function(now, fx) {
          topY = now;

          if (plusOrMinus === 1) {
            //schwanken
            angle = (Math.sin(now / 10) * 30) * plusOrMinus;
          } else {
            //ganze Drehung
            if (trueR){
            angle = now * addRotation;
          } else {
            angle = now * -addRotation;
          }
          }

          if (fx.prop === 'opacity') {
            //console.log(now);
            opaQ = now;
            //console.log(opaQ);
          }
          //randomH/5 amplitude je kleiner der divisor desto grösser die amplitude
          leftX = ((Math.sin(now / 20) + 2 * Math.sin(now / 40)) * Math.floor(randomH/7)) * plusOrMinus; //randomH/5 amplitude
          //console.log(leftX);
          jQuery(this).css({
            opacity: opaQ,
            transform: 'translateX(' + leftX + x + 'px) translateY(' + topY + 'px) rotateZ(' + angle + 'deg)',
          });
        }, // ende step 
        duration: timeX,
        easing: "easeOutSine",
        //complete: function(){
          //console.log('getCurrentRotation(jQuery(this))');
          //angleX = getRotationDegrees(jQuery(this));
          //angleX = angleX*plusOrMinus;
        //}
      }).animate({
        opacity: 0,
        //rotation: -360,
        //left: leftX + x + endX+100,
        //top: yval + yweg,
      }, {
        step: function(now,fx) {
      
        //angle -= gurk;
        //leftX +=Math.cos(now*5)*1;

        if (trueR){
          angle += addRotation2;
          leftX +=Math.cos(now*10)*plusOrMinus;
          topY -= Math.sin(now*10)*plusOrMinus2;

        } else {
          angle -= addRotation2;
          leftX -=Math.cos(now*10)*plusOrMinus;
          topY += Math.sin(now*10)*plusOrMinus2;
        }
           

            if (fx.prop === 'opacity') {
            //console.log(now);
            opaQ = now;
            //console.log(opaQ);
          }

          
          jQuery(this).css({'transform':'translateX(' + leftX + 'px) translateY(' + topY + 'px) rotate('+angle+'deg)','opacity':opaQ});  
        },
        duration:time2,
        easing: "linear",
    }).fadeOut(700, function() {
        jQuery(this).remove();
      });
      Tvar = window.setTimeout(hintergrundAnim, timeout);
  }//ende if hasAnim

} //ende funtion// JavaScript Document

/*call hintergrundAnim*/
(function($) {
  $(function() {
    var $window = $(window), TvarX, ftimeout = 500;
    hasAnim = true;

    /*if ($('.animelement').length){
      console.log('vorhanden');
    } else {
      console.log('nicht vorhanden');
    }*/

    function bganim() {
      if ($window.width() > 320) { //anfang if
        if (hasAnim === false) {
          return;
        }

        hasAnim = true;
        hintergrundAnim();

      } //ende if 
      else {
        hasAnim = false;
        $('.animelement').stop().remove();
        clearTimeout(Tvar);
        clearTimeout(TvarX);
        fCounter = 0;
      }
    } //ende funktion

    //bganim();
    TvarX = window.setTimeout(bganim, ftimeout);


    $window.blur(function() {

      $('.animelement').stop().remove();
      hasAnim = false;
      clearTimeout(Tvar);
      clearTimeout(TvarX);
      fCounter = 0;
      //test ob animelent ist vorhanden oder nicht
      /*if ($('.animelement').length){
      console.log('vorhanden');
    } else {
      console.log('nicht vorhanden');
    }*/
    });

    $window.on('focus', function() {
      hasAnim = true;
      //bganim();
      TvarX = window.setTimeout(bganim, ftimeout);
    });

    $window.resize(function() {
      $('.animelement').stop().remove();
      hasAnim = false;
      clearTimeout(Tvar);
      clearTimeout(TvarX);
      fCounter = 0;
      //test ob animelent ist vorhanden oder nicht
      /*if ($('.animelement').length){
      console.log('vorhanden');
    } else {
      console.log('nicht vorhanden');
    }*/

      waitForFinalEvent(function(){
      hasAnim = true;
      //console.log('Resize...');
      //bganim();
      TvarX = window.setTimeout(bganim, ftimeout);
      //console.log('restart anim');
    }, 1000, "restartX amim");
      //return false;
    });

    /*$window.resize(function() {
      //bganim();
    });*/
  });
})(jQuery);
